# wawjs-snippets

School pet project.

Distributing and installing Snippets for:

- JavaScript
	- node.js APIs
	- mocha
	- ...
- for editors
	- Sublime Text 3
	- ...

## Installing

	npm install https://github.com/ainthek/wawjs-snippets.git

This will create 

	$HOME/$SUMLIME/wawjs/*.sublime-snippet files	

## Development

Clone repo
	
	https://github.com/ainthek/wawjs-snippets.git

Run 
	
	npm install

Make changes, create new files, make fixes

Then:

	npm run build

Then test

	TODO:

	
Then commit and PR.



