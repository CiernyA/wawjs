// defineProperty
// wawjs - defineProperty

Object.defineProperty(obj, key, {
  value: null
  // ,enumerable: false
  // ,writable:false
  // ,configurable:false
});